console.log("hello javascript league")
console.log(1+2)

const pi = 3.1415;
var x = 1;
console.log(x);
var y=1.4;
console.log(y);
var z = "hello";
console.log(z);
var a = [x,y,z];
console.log(a);
var lst = [1,"0",[1,2],4.0,true];
console.log(lst);
var obj = {
    name :"Mr.ABD",
    age :"23",
    job:"AI Engineer",
    address : "Bengaluru"
}
console.log(obj)
let phone ={
    brand:'Apple',
    country:'America',
    name:'15 pro max',
    weight:200,    
    color:['Titanium','Black','Gold']
}
console.log(phone)
let str1='hello';
let str2 ="world";
let str3 = `hello world`;
console.log(str3)
let outcome = [
[1,2,3,4,5,6],
[4,2,1,5,3,6],
[1,6,5,2,4,3],
[4,3,1,2,6,5],
[6,5,3,4,2,1],
[4,5,6,1,2,3]
]
console.log(outcome[1][3])
console.log(outcome[4][3])